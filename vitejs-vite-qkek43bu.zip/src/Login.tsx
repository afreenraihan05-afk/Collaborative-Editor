import { useState } from 'react';

type Props = {
  onLogin: (name: string) => void;
};

function Login({ onLogin }: Props) {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    setError('');

    if (!email || !password || (isRegister && !name)) {
      setError('Please fill in all fields');
      return;
    }

    // Abhi browser me save ho raha hai, baad me backend se replace hoga
    const users = JSON.parse(localStorage.getItem('users') || '[]');

    if (isRegister) {
      if (users.find((u: any) => u.email === email)) {
        setError('This email is already registered');
        return;
      }
      users.push({ name, email, password });
      localStorage.setItem('users', JSON.stringify(users));
      onLogin(name);
    } else {
      const user = users.find(
        (u: any) => u.email === email && u.password === password
      );
      if (!user) {
        setError('Invalid email or password');
        return;
      }
      onLogin(user.name);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h1>Collaborative Editor</h1>
        <p className="auth-sub">Real-time code and whiteboard workspace</p>
        <h2 style={{ marginTop: '22px' }}>
          {isRegister ? 'Create your account' : 'Welcome back'}
        </h2>

        {isRegister && (
          <input
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        )}

        <input
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          placeholder="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {error && <p className="error-text">{error}</p>}

        <button className="auth-btn" onClick={handleSubmit}>
          {isRegister ? 'Register' : 'Login'}
        </button>

        <p className="auth-link" onClick={() => setIsRegister(!isRegister)}>
          {isRegister
            ? 'Already have an account? Login'
            : "Don't have an account? Register here"}
        </p>
      </div>
    </div>
  );
}

export default Login;
