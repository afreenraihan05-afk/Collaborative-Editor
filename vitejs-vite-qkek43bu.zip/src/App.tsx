import { useState, useEffect } from 'react';
import Login from './Login';
import Editor from '@monaco-editor/react';
import Whiteboard from './Whiteboard';
type DocType = 'Code' | 'Whiteboard';

type Version = {
  number: number;
  author: string;
  time: string;
  content: string;
};

type Doc = {
  id: number;
  title: string;
  type: DocType;
  owner: string;
  content: string;
  updated: string;
  language?: string;
  versions?: Version[];
  shared?: { name: string; role: 'Editor' | 'Viewer' }[];
};

function App() {
  const [user, setUser] = useState<string | null>(
    localStorage.getItem('currentUser')
  );
  const [docs, setDocs] = useState<Doc[]>(() =>
    JSON.parse(localStorage.getItem('docs') || '[]')
  );
  const [openId, setOpenId] = useState<number | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<DocType>('Code');
  const [previewV, setPreviewV] = useState<Version | null>(null);
  const [online, setOnline] = useState<string[]>([]);

  // Documents ko browser me save karte rehna
  useEffect(() => {
    localStorage.setItem('docs', JSON.stringify(docs));
  }, [docs]);

  // Auto snapshot: har 30 second me, agar content badla ho
  useEffect(() => {
    if (!openId || !user) return;
    const t = setInterval(() => {
      setDocs((cur) =>
        cur.map((d) => {
          if (d.id !== openId) return d;
          const versions = d.versions || [];
          const last = versions[versions.length - 1];
          if (last ? last.content === d.content : !d.content) return d;
          return {
            ...d,
            versions: [
              ...versions,
              {
                number: versions.length + 1,
                author: user,
                time: new Date().toLocaleString(),
                content: d.content,
              },
            ],
          };
        })
      );
    }, 30000);
    return () => clearInterval(t);
  }, [openId, user]);
  // Dusre tab me change aaye to yahan bhi turant update ho jaye
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === 'docs' && e.newValue) setDocs(JSON.parse(e.newValue));
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  // Kaun kaun is document ko khol ke baitha hai
  useEffect(() => {
    if (!user || !openId) return;
    const me = Math.random().toString(36).slice(2, 8);
    const ch = new BroadcastChannel('presence-' + openId);
    const peers: Record<string, { name: string; t: number }> = {};

    const refresh = () => {
      const now = Date.now();
      Object.keys(peers).forEach((k) => {
        if (now - peers[k].t > 4000) delete peers[k];
      });
      setOnline([user, ...Object.values(peers).map((p) => p.name)]);
    };

    ch.onmessage = (e) => {
      peers[e.data.id] = { name: e.data.name, t: Date.now() };
      refresh();
    };

    const ping = setInterval(() => {
      ch.postMessage({ id: me, name: user });
      refresh();
    }, 2000);
    ch.postMessage({ id: me, name: user });

    return () => {
      clearInterval(ping);
      ch.close();
    };
  }, [openId, user]);
  const handleLogin = (name: string) => {
    localStorage.setItem('currentUser', name);
    setUser(name);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setUser(null);
    setOpenId(null);
    setPreviewV(null);
  };

  // Login nahi hai to Login page (hooks ke BAAD hi hona chahiye)
  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const roleOf = (d: Doc): 'Owner' | 'Editor' | 'Viewer' | null => {
    if (d.owner === user) return 'Owner';
    const s = (d.shared || []).find(
      (x) => x.name.toLowerCase() === user.toLowerCase()
    );
    return s ? s.role : null;
  };
  const myDocs = docs.filter((d) => roleOf(d) !== null);
  const openDoc = docs.find((d) => d.id === openId);
  const canEdit = openDoc ? roleOf(openDoc) !== 'Viewer' : false;

  const createDoc = () => {
    if (!newTitle.trim()) return;
    const doc: Doc = {
      id: Date.now(),
      title: newTitle.trim(),
      type: newType,
      owner: user,
      content: '',
      updated: new Date().toLocaleString(),
      language: 'javascript',
      versions: [],
    };
    setDocs([doc, ...docs]);
    setNewTitle('');
  };

  const renameDoc = (id: number) => {
    const title = prompt('New name:');
    if (!title) return;
    setDocs(docs.map((d) => (d.id === id ? { ...d, title } : d)));
  };

  const deleteDoc = (id: number) => {
    if (!confirm('Delete this document?')) return;
    setDocs(docs.filter((d) => d.id !== id));
  };
  const duplicateDoc = (id: number) => {
    const src = docs.find((d) => d.id === id);
    if (!src) return;
    const copy: Doc = {
      ...src,
      id: Date.now(),
      title: src.title + ' (copy)',
      updated: new Date().toLocaleString(),
      versions: [],
    };
    setDocs([copy, ...docs]);
  };
  const shareDoc = (id: number) => {
    const name = prompt('Kis user ka naam share karna hai? (jo registered ho)');
    if (!name) return;
    const role =
      prompt('Role likho: Editor ya Viewer') === 'Viewer' ? 'Viewer' : 'Editor';
    setDocs(
      docs.map((d) =>
        d.id === id
          ? { ...d, shared: [...(d.shared || []), { name: name.trim(), role }] }
          : d
      )
    );
  };

  // Typing ke saath auto-save (koi Save button nahi)
  const updateContent = (id: number, content: string) => {
    setDocs(
      docs.map((d) =>
        d.id === id
          ? { ...d, content, updated: new Date().toLocaleString() }
          : d
      )
    );
  };

  const changeLanguage = (id: number, language: string) => {
    setDocs(docs.map((d) => (d.id === id ? { ...d, language } : d)));
  };

  // Naya version banane ka helper
  const addVersion = (d: Doc, content: string): Doc => {
    const versions = d.versions || [];
    return {
      ...d,
      content,
      updated: new Date().toLocaleString(),
      versions: [
        ...versions,
        {
          number: versions.length + 1,
          author: user,
          time: new Date().toLocaleString(),
          content,
        },
      ],
    };
  };

  // Manual snapshot (testing aur screenshots ke liye)
  const saveSnapshot = (id: number) => {
    setDocs(docs.map((d) => (d.id === id ? addVersion(d, d.content) : d)));
  };

  // Restore purani history delete nahi karta, naya version banata hai
  const restoreVersion = (id: number, v: Version) => {
    setDocs(docs.map((d) => (d.id === id ? addVersion(d, v.content) : d)));
    setPreviewV(null);
  };

  return (
    <div>
      {/* ===== Navbar ===== */}
      <div className="navbar">
        <div className="logo">⚡ Collaborative Editor</div>
        <div className="nav-right">
          <div className="avatar">{user.charAt(0).toUpperCase()}</div>
          <span>{user}</span>
          <button className="secondary" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>

      <div className="container">
        {openDoc ? (
          /* ===== Workspace ===== */
          <div>
            <div className="workspace-head">
              <button
                className="secondary"
                onClick={() => {
                  setOpenId(null);
                  setPreviewV(null);
                }}
              >
                ← Back
              </button>
              <h2>{openDoc.title}</h2>
              <span
                className={`badge ${
                  openDoc.type === 'Code' ? 'code' : 'board'
                }`}
              >
                {openDoc.type}
              </span>
            </div>

            {openDoc.type === 'Code' ? (
              <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
                {/* Editor side */}
                <div style={{ flex: 3, minWidth: '300px' }}>
                  <div
                    style={{
                      display: 'flex',
                      gap: '10px',
                      marginBottom: '10px',
                    }}
                  >
                    <select
                      style={{ marginTop: 0, maxWidth: '180px' }}
                      value={openDoc.language || 'javascript'}
                      onChange={(e) =>
                        changeLanguage(openDoc.id, e.target.value)
                      }
                    >
                      <option value="javascript">JavaScript</option>
                      <option value="python">Python</option>
                      <option value="java">Java</option>
                      <option value="cpp">C++</option>
                      <option value="html">HTML</option>
                    </select>
                    <button
                      className="secondary"
                      onClick={() => saveSnapshot(openDoc.id)}
                    >
                      Save snapshot
                    </button>
                  </div>

                  {previewV && (
                    <div
                      style={{
                        background: '#fef3c7',
                        padding: '10px',
                        borderRadius: '8px',
                        marginBottom: '10px',
                      }}
                    >
                      Previewing version {previewV.number} (read-only){' '}
                      <button
                        onClick={() => restoreVersion(openDoc.id, previewV)}
                      >
                        Restore
                      </button>{' '}
                      <button
                        className="secondary"
                        onClick={() => setPreviewV(null)}
                      >
                        Close
                      </button>
                    </div>
                  )}

                  <Editor
                    height="420px"
                    theme="vs-dark"
                    language={openDoc.language || 'javascript'}
                    value={previewV ? previewV.content : openDoc.content}
                    onChange={(v) =>
                      !previewV && updateContent(openDoc.id, v || '')
                    }
                    options={{
                      readOnly: !!previewV || !canEdit,
                      minimap: { enabled: false },
                      fontSize: 14,
                    }}
                  />
                </div>

                {/* Version history side panel */}
                <div
                  className="create-box"
                  style={{
                    flex: 1,
                    minWidth: '220px',
                    maxHeight: '480px',
                    overflowY: 'auto',
                  }}
                >
                  <h3>Online ({online.length})</h3>
                  {online.map((n, i) => (
                    <p key={i} className="doc-meta">
                      🟢 {n}
                    </p>
                  ))}
                  <hr
                    style={{
                      margin: '12px 0',
                      border: 'none',
                      borderTop: '1px solid #e5e7eb',
                    }}
                  />
                  <h3>Version History</h3>
                  {(openDoc.versions || []).length === 0 && (
                    <p className="doc-meta" style={{ marginTop: '10px' }}>
                      No versions yet. Write something and wait 30 seconds, or
                      click Save snapshot.
                    </p>
                  )}
                  {[...(openDoc.versions || [])].reverse().map((v) => (
                    <div
                      key={v.number}
                      style={{
                        borderBottom: '1px solid #e5e7eb',
                        padding: '10px 0',
                        cursor: 'pointer',
                      }}
                      onClick={() => setPreviewV(v)}
                    >
                      <strong>Version {v.number}</strong>
                      <p className="doc-meta">{v.author}</p>
                      <p className="doc-meta">{v.time}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <Whiteboard
                value={openDoc.content}
                readOnly={!canEdit}
                onChange={(json) => updateContent(openDoc.id, json)}
              />
            )}
          </div>
        ) : (
          <>
            {/* ===== Create document ===== */}
            <div className="create-box">
              <h3 style={{ marginBottom: '12px' }}>Create new document</h3>
              <div className="create-row">
                <input
                  placeholder="Document name"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                />
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as DocType)}
                >
                  <option value="Code">Code</option>
                  <option value="Whiteboard">Whiteboard</option>
                </select>
                <button onClick={createDoc}>+ Create</button>
              </div>
            </div>

            {/* ===== Documents list ===== */}
            <h2 className="section-title">My Documents ({myDocs.length})</h2>

            {myDocs.length === 0 ? (
              <div className="empty">No documents yet. Create one above.</div>
            ) : (
              <div className="grid">
                {myDocs.map((d) => (
                  <div className="doc-card" key={d.id}>
                    <span
                      className={`badge ${
                        d.type === 'Code' ? 'code' : 'board'
                      }`}
                    >
                      {d.type}
                    </span>
                    <h3>{d.title}</h3>
                    <p className="doc-meta">Updated: {d.updated}</p>
                    <div className="doc-actions">
                      <button onClick={() => setOpenId(d.id)}>Open</button>
                      <button
                        className="secondary"
                        onClick={() => renameDoc(d.id)}
                      >
                        Rename
                      </button>
                      <button
                        className="secondary"
                        onClick={() => duplicateDoc(d.id)}
                      >
                        Duplicate
                      </button>
                      {d.owner === user && (
                        <button
                          className="secondary"
                          onClick={() => shareDoc(d.id)}
                        >
                          Share
                        </button>
                      )}

                      <button
                        className="danger"
                        onClick={() => deleteDoc(d.id)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;
