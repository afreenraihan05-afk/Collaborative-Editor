import { useRef, useState, useEffect } from 'react';

type Shape = {
  tool: 'pen' | 'rect' | 'circle' | 'line';
  color: string;
  width: number;
  points: { x: number; y: number }[];
};

type Props = {
  value: string; // JSON string of shapes
  onChange: (json: string) => void;
  readOnly?: boolean;
};

export default function Whiteboard({ value, onChange, readOnly }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [tool, setTool] = useState<Shape['tool']>('pen');
  const [color, setColor] = useState('#4f46e5');
  const [width, setWidth] = useState(3);
  const [current, setCurrent] = useState<Shape | null>(null);

  const shapes: Shape[] = (() => {
    try {
      return value ? JSON.parse(value) : [];
    } catch {
      return [];
    }
  })();

  // Canvas par sab shapes dobara draw karo
  const draw = (list: Shape[]) => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d')!;
    ctx.clearRect(0, 0, c.width, c.height);
    list.forEach((s) => {
      ctx.strokeStyle = s.color;
      ctx.lineWidth = s.width;
      ctx.lineCap = 'round';
      ctx.beginPath();
      const a = s.points[0];
      const b = s.points[s.points.length - 1];
      if (s.tool === 'pen') {
        ctx.moveTo(a.x, a.y);
        s.points.forEach((p) => ctx.lineTo(p.x, p.y));
      } else if (s.tool === 'line') {
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
      } else if (s.tool === 'rect') {
        ctx.rect(a.x, a.y, b.x - a.x, b.y - a.y);
      } else if (s.tool === 'circle') {
        const r = Math.hypot(b.x - a.x, b.y - a.y);
        ctx.arc(a.x, a.y, r, 0, Math.PI * 2);
      }
      ctx.stroke();
    });
  };

  useEffect(() => {
    draw(current ? [...shapes, current] : shapes);
  });

  const pos = (e: React.MouseEvent) => {
    const r = canvasRef.current!.getBoundingClientRect();
    return {
      x: ((e.clientX - r.left) * canvasRef.current!.width) / r.width,
      y: ((e.clientY - r.top) * canvasRef.current!.height) / r.height,
    };
  };

  const down = (e: React.MouseEvent) => {
    if (readOnly) return;
    setCurrent({ tool, color, width, points: [pos(e)] });
  };

  const move = (e: React.MouseEvent) => {
    if (!current) return;
    const p = pos(e);
    setCurrent({
      ...current,
      points: tool === 'pen' ? [...current.points, p] : [current.points[0], p],
    });
  };

  const up = () => {
    if (!current) return;
    onChange(JSON.stringify([...shapes, current]));
    setCurrent(null);
  };

  const undo = () => onChange(JSON.stringify(shapes.slice(0, -1)));
  const clear = () => onChange('[]');

  return (
    <div>
      {!readOnly && (
        <div
          style={{
            display: 'flex',
            gap: '8px',
            flexWrap: 'wrap',
            marginBottom: '10px',
            alignItems: 'center',
          }}
        >
          {(['pen', 'rect', 'circle', 'line'] as const).map((t) => (
            <button
              key={t}
              className={tool === t ? '' : 'secondary'}
              onClick={() => setTool(t)}
            >
              {t === 'pen'
                ? '✏️ Pen'
                : t === 'rect'
                ? '▭ Rectangle'
                : t === 'circle'
                ? '◯ Circle'
                : '／ Line'}
            </button>
          ))}
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            style={{
              width: '44px',
              height: '38px',
              padding: '2px',
              marginTop: 0,
            }}
          />
          <select
            value={width}
            onChange={(e) => setWidth(Number(e.target.value))}
            style={{ width: '110px', marginTop: 0 }}
          >
            <option value={2}>Thin</option>
            <option value={3}>Normal</option>
            <option value={6}>Thick</option>
            <option value={10}>Extra thick</option>
          </select>
          <button className="secondary" onClick={undo}>
            ↶ Undo
          </button>
          <button className="danger" onClick={clear}>
            Clear
          </button>
        </div>
      )}
      <canvas
        ref={canvasRef}
        width={900}
        height={420}
        onMouseDown={down}
        onMouseMove={move}
        onMouseUp={up}
        onMouseLeave={up}
        style={{
          width: '100%',
          background: 'white',
          border: '1px solid #d1d5db',
          borderRadius: '12px',
          cursor: readOnly ? 'default' : 'crosshair',
        }}
      />
    </div>
  );
}
